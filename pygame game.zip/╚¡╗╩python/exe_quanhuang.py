import pygame as py
import time
from pygame.locals import *
jingong=0#记录在一定时间按下j的次数
#begin_mp3 = py.mixer.Sound('D:/begin.mp3')
score=0#得分
lock=0#判断是否上锁
j_iter=0;#j按键的迭代次数j
img = py.image.load('./yuanshen3.jpg')
zombie_tx=py.image.load('./zombie.png')
boss_tx=py.image.load('./boss.png')
reddragon_tx=py.image.load('./reddragon.png')
youdied=py.image.load('./youdied.png')
touxiang=py.image.load('./resize_touxiang.png')
preview=[]#针对特殊gif形式的
is_pause=False
game=1
bashen=None
screen=py.display.set_mode((1000,500))
action=-1#人物动作表示
class Base(object):
    def __init__(self,x,y):
        self.x=x
        self.y=y
class Player(Base):
    global screen
    global reddragon
    global action
    global img
    global jingong
    global preview
    def __init__(self,character,x,y,iters):
        Base.__init__(self,x,y)
        self.character=character
        self.keydown_list=[]
        self.preview_HP=8
        self.jilu=999
        self.wudi=False
        self.gouyu = py.image.load('./gouyu.png')
        self.gouyu7 = py.image.load('./gouyu7.png')
        self.gouyu6 = py.image.load('./gouyu6.png')
        self.gouyu5 = py.image.load('./gouyu5.png')
        self.gouyu4 = py.image.load('./gouyu4.png')
        self.gouyu3 = py.image.load('./gouyu3.png')
        self.gouyu2 = py.image.load('./gouyu2.png')
        self.gouyu1 = py.image.load('./gouyu1.png')
        self.HP=8
        self.j=[]
        for i in range(10):
            self.load=py.image.load('./gif split/'+f'{character} attack/data/00{i}.png')
            self.j.append(self.load)
        for i in range(10,23):
            self.load=py.image.load('./gif split/'+f'{character} attack/data/0{i}.png')
            self.j.append(self.load)
        self.stand=[]
        self.s=0
        for i in range(9):
            self.s=py.image.load('./gif split/'+f'{character} stand/data/00{i}.png')
            self.stand.append(self.s)
        self.run=[]
        self.r=[1]*8
        for i in range(8):
            self.r[i]=py.image.load('./gif split/'+f'{character} run/data/00{i}.png')
            self.run.append(self.r[i])
        self.zhaoyi=[]
        self.z1=[1]*19
        for i in range(10):
           self.z1[i]=py.image.load('./gif split/'+f'{character} zhaoyi/data/00{i}.png')
           self.zhaoyi.append(self.z1[i])
        for i in range(10,19):
           self.z1[i]=py.image.load('./gif split/'+f'{character} zhaoyi/data/0{i}.png')
           self.zhaoyi.append(self.z1[i])
        self.zhaoer=[]
        self.z2=[0]*43
        for i in range(42,6,-1):
            self.z2[i]=py.image.load('./gif split/'+f'{character} zhaoer/data/0{i+3}.png')
            self.zhaoer.append(self.z2[i])
        for i in range(6,0,-1):
            self.z2[i]=py.image.load('./gif split/'+f'{character} zhaoer/data/00{i+3}.png')
            self.zhaoer.append(self.z2[i])
        self.back=[]
        self.b=[1]*9
        for i in range(9):
            self.b[i]=py.image.load('./gif split/'+f'{character} back/data/00{i}.png')
            self.back.append(self.b[i])
        self.debut=[]
        self.de=[1]*12
        for i in range(10):
            self.de[i]=py.image.load('./gif split/'+f'{character} debut/data/00{i}.png')
            self.debut.append(self.de[i])
        self.debut.append(py.image.load('./gif split/'+f'{character} debut/data/010.png'))
        self.debut.append(py.image.load('./gif split/'+f'{character} debut/data/011.png'))
        self.gong1=[]
        self.g1=[0]*10
        for i in range(10):
            self.g1[i]=py.image.load('./gif split/'+f'{character} attack/data/00{i}.png')
            self.gong1.append(self.g1[i])
        self.gong2=[]
        self.g2=[0]*27
        for i in range(10,27):
            self.g2[i]=py.image.load('./gif split/'+f'{character} attack/data/0{i}.png')
            self.gong2.append(self.g2[i])
        self.straightjump=[]
        for i in range(10):
            self.sjump=py.image.load('./gif split/'+f'{character} straight jump/data/00{i}.png')
            self.straightjump.append(self.sjump)
        for i in range(10,13):
            self.sjump=py.image.load('./gif split/'+f'{character} straight jump/data/0{i}.png')
            self.straightjump.append(self.sjump)
        self.jitui=[]
        for i in range(29,9,-1):
            self.sjump=py.image.load(f'./击倒_爱给网_aigei_com/data/0{i}.png')
            self.jitui.append(self.sjump)
        for i in range(9,-1,-1):
            self.sjump=py.image.load(f'./击倒_爱给网_aigei_com/data/00{i}.png')
            self.jitui.append(self.sjump)
        self.win=[]
        for i in range(0,10):
            self.win.append(py.image.load(f'./拳皇素材/jiqi/data/00{i}.png'))
        for i in range(10,69):
            self.win.append(py.image.load(f'./拳皇素材/jiqi/data/0{i}.png'))
    def display(self):
        py.display.update(i,(self.x,330))
    def key_down(self,key):
        self.keydown_list.append(key)
    def key_up(self,key):
        if len(self.keydown_list)!=0:
            try:
                self.keydown_list.remove(key)
            except Exception:
                pass
    def left(self):
        if self.x>0:
            self.x-=1
            screen.blit(self.back[int((time.time()%0.8)*10)],(self.x,330))
        else:
            self.x=0
            screen.blit(self.back[int((time.time() % 0.8) * 10)], (self.x, 330))
    def right(self):

        if self.x<=900 and reddragon.x-self.x>=60:
            self.x+=2.5
            screen.blit(self.run[int((time.time()%0.8)*10)],(self.x,330))
        else:
            self.x=self.x
            screen.blit(self.run[int((time.time() % 0.8) * 10)], (self.x, 330))
    def attack(self):
        global jingong
        global action
        action=0
        if jingong==0:
            for i in range(10):
                preview.append(self.j[i])
                preview.append(self.j[i])
                preview.append(self.j[i])
                preview.append(self.j[i])
            jingong=(jingong+1)%3
        elif jingong==1:
            for i in range(10,17):
                preview.append(self.j[i])
                preview.append(self.j[i])
                preview.append(self.j[i])
                preview.append(self.j[i])
                preview.append(self.j[i])
            jingong=(jingong+1)%3
        elif jingong==2:
            for i in range(16,23):
                preview.append(self.j[i])
                preview.append(self.j[i])
                preview.append(self.j[i])
                preview.append(self.j[i])
            jingong=(jingong+1)%3
    def u(self):
        global action
        action=1
        for i in range(7,19):
            preview.append(self.zhaoyi[i])
            preview.append(self.zhaoyi[i])
            preview.append(self.zhaoyi[i])
    def i(self):
        global action
        action=2
        py.mixer.init()
        b=py.mixer.Sound('./拳皇素材/zhaoer.mp3')
        b.set_volume(0.1)
        b.play()
        for i in range(42):
            preview.append(self.zhaoer[i])
            preview.append(self.zhaoer[i])
    def pressmove(self):
       global boss
       if len(self.keydown_list)!=0:
           if len(self.keydown_list)==1:
               if self.keydown_list[0]==ord('a'):
                   self.left()
               elif self.keydown_list[0]==ord('d'):
                   self.right()
               elif self.keydown_list[0]==ord('j'):
                   self.attack()
               elif self.keydown_list[0]==ord('u'):
                   self.u()
               elif self.keydown_list[0]==ord('i'):
                   self.i()
           elif len(self.keydown_list)>=2:
               if ord('i') in self.keydown_list and ord('u') in self.keydown_list:
                   self.i()
                   self.keydown_list.clear()
               elif ord('i') in self.keydown_list:
                   self.i()
               elif ord('u') in self.keydown_list and ord('i') not in self.keydown_list:
                   self.u()
               elif ord('j') in self.keydown_list and ord('i') not in self.keydown_list and ord('u') not in self.keydown_list:
                   self.attack()
               else:
                   self.keydown_list.clear()
       else:
           screen.blit(bashen.stand[int((time.time() % 1) * 8)], (self.x, 330))
       if boss.HP<=0:
           self.end_win()
    def function(self):
     global lock
     for event in py.event.get():
        if event.type ==QUIT:
            exit()
        elif event.type==KEYDOWN:
            if event.key==K_d:
                    self.key_down(K_d)
            elif event.key==K_a:
                    self.key_down(K_a)
            elif event.key==K_k:
                    self.key_down(K_k)
            elif event.key==K_u:
                    self.key_down(K_u)
            elif event.key==K_j:
                    self.key_down(K_j)
            elif event.key==K_i:
                    self.key_down(K_i)
            elif event.key==K_ESCAPE:
                exit()
        elif event.type==KEYUP:
            if event.key==K_d:
                self.key_up(K_d)
            elif event.key==K_a:
                self.key_up(K_a)
            elif event.key==K_k:
                self.key_up(K_k)
    def hitted_act(self):
        if self.HP<=0:
            for i in range(30):
                preview.append(self.jitui[i])
                preview.append(self.jitui[i])
    def hitted_interval(self):
        if self.preview_HP>self.HP:
            self.jilu=time.time()
            self.preview_HP=self.HP
            self.wudi=True
    def end_win(self):
        global game
        c = py.mixer.Sound('./youwin.wav')
        c.set_volume(0.2)
        c.play()
        for i in range(len(self.win)-2):
            if game==0:
                self.keydown_list.clear()
                break
            screen.blit(img,(0,0))
            screen.blit(self.win[i],(self.x,self.y))
            time.sleep(0.04)
            py.display.update()
        game=0
class enemy0(Base):
    def __init__(self,character,x,y):
        Base.__init__(self,x,y)
        self.x=x
        self.y=y
        self.HP=3
        self.mark=0
        py.mixer.init()
        self.hitted = py.mixer.Sound('./拳皇素材/hit.mp3')
        self.gouyu3 = py.image.load('./gouyu3.png')
        self.gouyu2 = py.image.load('./gouyu2.png')
        self.gouyu1 = py.image.load('./gouyu1.png')
        self.walk=[]
        for i in range(6):
            self.walk.append(py.image.load(rf'.\gif split\reddragon\data\00{i}.png'))
    def move(self):
        global bashen
        if self.x>0 and self.x>=(bashen.x+40):
            self.x=self.x-0.5
            screen.blit(self.walk[int((time.time() % 1) * 5)], (self.x, self.y))
        else:
            self.x=self.x
            screen.blit(self.walk[int((time.time() % 1) * 5)], (self.x, self.y))
    def die(self):
        global score
        self.x=1050
        self.HP=3
        score+=1
        self.mark=0
    def ishitted(self):
        global bashen
        if (self.x - bashen.x) <= 65 and self.HP >= 1 and action==0:
            if self.mark!=1:
                self.hitted.play()
                self.hitted.set_volume(0.3)
                self.HP -= 1
                self.x = self.x + 20
            self.mark=1
            bashen.key_up(K_j)
        elif (self.x - bashen.x) <= 80 and self.HP >= 1 and action==1:
            if self.mark!=1:
                self.HP -= 2
                self.x = self.x + 20
            self.mark=1
            bashen.key_up(K_u)
        elif (self.x - bashen.x) <= 180 and self.HP >= 1 and action==2:
            if self.mark!=1:
                self.HP -= 1
                self.x = self.x + 20
            self.mark=1
            bashen.key_up(K_i)
        elif action!=(0 or 1 or 2) and (self.x - bashen.x) <= 60 and bashen.wudi == False:
            bashen.HP -= 1
            bashen.x -= 20
class enemy1(Base):
    def __init__(self,character,x,y):
        Base.__init__(self,x,y)
        self.x=x
        self.mark=0
        py.mixer.init()
        self.hitted=py.mixer.Sound('./hit.mp3')
        self.y=y
        self.HP=5
        self.gouyu5 = py.image.load('./gouyu5.png')
        self.gouyu4 = py.image.load('./gouyu4.png')
        self.gouyu3 = py.image.load('./gouyu3.png')
        self.gouyu2 = py.image.load('./gouyu2.png')
        self.gouyu1 = py.image.load('./gouyu1.png')
        self.walk=[]
        for i in range(10):
            self.walk.append(py.image.load(rf'.\拳皇素材\足球僵尸(FootballZombie)_爱给网_aigei_com\data\00{i}.png'))
        self.walk.append(py.image.load(rf'.\拳皇素材\足球僵尸(FootballZombie)_爱给网_aigei_com\data\010.png'))
    def move(self):
        global bashen
        if self.x > 0 and self.x >= (bashen.x + 40):
            self.x = self.x - 0.6
            screen.blit(self.walk[int((time.time() % 0.8) * 12.5)], (self.x, self.y))
        else:
            self.x = self.x
            screen.blit(self.walk[int((time.time() %0.8) * 12.5)], (self.x, self.y))
    def die(self):
        global score
        self.x=1050
        self.HP=5
        score+=2
    def ishitted(self):
        global bashen
        if (self.x - bashen.x) <= 68 and self.HP >= 1 and action==0:
            if self.mark!=1:
                self.hitted.play()
                self.hitted.set_volume(0.5)
                self.HP -= 1
                self.x = self.x + 20
            self.mark=1
            bashen.key_up(K_j)
        elif (self.x - bashen.x) <= 80 and self.HP >= 1 and action==1:
            if self.mark!=1:
                self.HP -= 2
                self.x = self.x + 20
            self.mark=1
            bashen.key_up(K_u)
        elif (self.x - bashen.x) <= 180 and self.HP >= 1 and action==2:
            if self.mark!=1:
                self.HP -= 1
                self.x = self.x + 20
            self.mark=1
            bashen.key_up(K_i)
        elif action!=(0 or 1 or 2) and (
                self.x - bashen.x) <= 64 and bashen.wudi == False:
            bashen.HP -= 2
            bashen.x -= 20
class enemy2(Base):
    global score
    def __init__(self,character,x,y):
        Base.__init__(self,x,y)
        self.x=x
        self.y=y
        py.mixer.init()
        self.hitted = py.mixer.Sound('./hit.mp3')
        self.mark=0
        self.gouyu = py.image.load('./gouyu.png')
        self.gouyu7 = py.image.load('./gouyu7.png')
        self.gouyu6 = py.image.load('./gouyu6.png')
        self.gouyu5 = py.image.load('./gouyu5.png')
        self.gouyu4 = py.image.load('./gouyu4.png')
        self.gouyu3 = py.image.load('./gouyu3.png')
        self.gouyu2 = py.image.load('./gouyu2.png')
        self.gouyu1 = py.image.load('./gouyu1.png')
        self.HP=8
        self.walk=[]
        for i in range(9):
            self.walk.append(py.image.load(rf'.\boss\data\00{i}.png'))
    def move(self):
        global bashen
        if self.x > 0 and self.x >= (bashen.x + 40):
            self.x = self.x - 0.55
            screen.blit(self.walk[int((time.time() % 1) * 8)], (self.x, self.y))
        else:
            self.x = self.x
            screen.blit(self.walk[int((time.time() % 1) * 8)], (self.x, self.y))
    def ishitted(self):
        global bashen
        if (self.x - bashen.x) <= 65 and self.HP >= 1 and action==0:
            if self.mark!=1:
                self.hitted.play()
                self.hitted.set_volume(0.5)
                self.HP -= 1
                self.x = self.x + 10
            self.mark=1
            bashen.key_up(K_j)
        elif (self.x - bashen.x) <= 80 and self.HP >= 1 and action==1:
            if self.mark!=1:
                self.HP -= 2
                self.x = self.x + 10
            self.mark=1
            bashen.key_up(K_u)
        elif (self.x - bashen.x) <= 180 and self.HP >= 1 and action==2:
            if self.mark!=1:
                self.HP -= 1
                self.x = self.x + 10
            self.mark=1
            bashen.key_up(K_i)
        elif action!=(1 or 2 or 0) and (
                self.x - bashen.x) <= 70 and bashen.wudi == False:
            bashen.HP -= 3
            bashen.x -= 25
reddragon=enemy0('reddragon',1100,300)
zombie=enemy1('zombie',1100,300)
boss=enemy2('boss',1100,200)
def bgm():
    py.mixer.music.load('./sanguosha.mp3')#导入三国杀bgm
    py.mixer.music.set_volume(0.22)#设置音量
    py.mixer.music.play(-1)#循环播放
def main():
    global bashen
    global screen
    global game
    global img
    py.init()
    py.mixer.init()
    begin_mp3 = py.mixer.Sound('./begin.mp3')
    time.sleep(1.5)
    begin_mp3.play()
    begin_mp3.set_volume(0.3)
    bashen =Player('bashen',70,350,0)
    screen.blit(img,(0,0))
    for i in bashen.stand:
        screen.blit(img, (0,0))
        screen.blit(i, (130, 330))
        time.sleep(0.14)
        py.display.update()
    for i in bashen.debut:
        screen.blit(img,(0,0))
        screen.blit(i,(70,330))
        time.sleep(0.15)
        py.display.update()
    bgm()
    while (game):
        run()
def display_touxiang():
    global screen
    global zombie
    global bashen
    global boss
    global reddragon
    global zombie_tx
    global score
    global boss_tx
    global reddragon_tx
    screen.blit(touxiang,(0,0))
    if bashen.HP==8:
        screen.blit(bashen.gouyu,(100,50))
    elif bashen.HP==7:
        screen.blit(bashen.gouyu7,(100,50))
    elif bashen.HP==6:
        screen.blit(bashen.gouyu6,(100,50))
    elif bashen.HP==5:
        screen.blit(bashen.gouyu5,(100,50))
    elif bashen.HP==4:
        screen.blit(bashen.gouyu4,(100,50))
    elif bashen.HP==3:
        screen.blit(bashen.gouyu3,(100,50))
    elif bashen.HP==2:
        screen.blit(bashen.gouyu2,(100,50))
    elif bashen.HP==1:
        screen.blit(bashen.gouyu1,(100,50))
    if reddragon.HP==3 and score<=10:
        screen.blit(reddragon_tx, (920, 10))
        screen.blit(reddragon.gouyu3,(842,52))
    elif reddragon.HP==2 and score<=10:
        screen.blit(reddragon_tx, (920, 10))
        screen.blit(reddragon.gouyu2,(867,52))
    elif reddragon.HP==1 and score<=10:
        screen.blit(reddragon_tx, (920, 10))
        screen.blit(reddragon.gouyu1,(890,52))
    if score>=4 and zombie.HP==5 and score<=10:
        screen.blit(zombie_tx,(920,100))
        screen.blit(zombie.gouyu5,(794,141))
    elif score>=4 and zombie.HP==4 and score<=10:
        screen.blit(zombie_tx, (920, 100))
        screen.blit(zombie.gouyu4, (819, 141))
    elif score>=4 and zombie.HP==3 and score<=10:
        screen.blit(zombie_tx, (920, 100))
        screen.blit(zombie.gouyu3, (843, 140))
    elif score>=4 and zombie.HP==2 and score<=10:
        screen.blit(zombie_tx, (920, 100))
        screen.blit(zombie.gouyu2, (866, 140))
    elif score>=4 and zombie.HP==1 and score<=10:
        screen.blit(zombie_tx, (920, 100))
        screen.blit(zombie.gouyu1, (890, 140))
    if score>=11 and boss.HP==8:
        screen.blit(boss_tx, (910, 10))
        screen.blit(boss.gouyu, (707, 75))
    elif score>=11 and boss.HP==7:
        screen.blit(boss_tx, (910, 10))
        screen.blit(boss.gouyu7, (736, 75))
    elif score>=11 and boss.HP==6:
        screen.blit(boss_tx, (910, 10))
        screen.blit(boss.gouyu6, (758, 75))
    elif score>=11 and boss.HP==5:
        screen.blit(boss_tx, (910, 10))
        screen.blit(boss.gouyu5, (783, 75))
    elif score>=11 and boss.HP==4:
        screen.blit(boss_tx, (910, 10))
        screen.blit(boss.gouyu4, (810, 75))
    elif score>=11 and boss.HP==3:
        screen.blit(boss_tx, (910, 10))
        screen.blit(boss.gouyu3, (831, 75))
    elif score>=11 and boss.HP==2:
        screen.blit(boss_tx, (910, 10))
        screen.blit(boss.gouyu2, (856, 75))
    elif score>=11 and boss.HP==1:
        screen.blit(boss_tx, (910, 10))
        screen.blit(boss.gouyu1, (880, 75))
def monster_control():
    global score
    global reddragon
    global zombie
    global boss
    if score<=3:
        if reddragon.HP>=1:
            reddragon.move()
        elif reddragon.HP<=0:
            reddragon.die()
    elif score>=4 and score<=10:
        if reddragon.HP>=1:
            reddragon.move()
        elif reddragon.HP<=0:
            reddragon.die()
        if zombie.HP>=1:
            zombie.move()
        elif zombie.HP<=0:
            zombie.die()
    elif score>=11:
        reddragon.x=10000
        zombie.x=10000
        if boss.HP>=1:
            boss.move()
def run():#根据八神不同的状态执行不同情况
    global bashen
    global game
    global lock
    global img
    global screen
    global action
    global youdied
    global preview#试图塞入图片来分类讨论
    if len(preview)==0 and action!=(0 or 1 or 2) and bashen.HP>=1:
        bashen.hitted_interval()
        if bashen.HP!=10:
            a=time.time()
            if a-bashen.jilu>=1:
                bashen.wudi=False
        bashen.function()  #检测按键按下还是松开
        screen.blit(img, (0, 0))   #复原原屏幕起到了防止重影的作用
        display_touxiang()
        bashen.pressmove() #在没有执行动画的时候根据按键执行响应函数
        monster_control() #怪物函数
        reddragon.ishitted()
        boss.ishitted()
        zombie.ishitted()
        py.display.update()# 刷新屏幕
        time.sleep(0.011)
    elif len(preview)!=0 and action==0 and bashen.HP>=1:
        for i in range(len(preview)):
            screen.blit(img, (0, 0))#blit的顺序是有讲究的需要先屏幕刷新
            screen.blit(preview[i],(bashen.x,330))
            display_touxiang()
            monster_control()
            reddragon.ishitted()
            boss.ishitted()
            zombie.ishitted()
            py.display.update()
            time.sleep(0.011)
        preview=[]
        #lock=0
        bashen.key_up(K_j)
        reddragon.mark=0#防止一次技能造成多次伤害
        zombie.mark=0
        boss.mark=0
        action=-1
    elif len(preview)!=0 and action==1 and bashen.HP>=1:
        for i in range(len(preview)):
            screen.blit(img, (0, 0))  # blit的顺序是有讲究的需要先屏幕刷新
            display_touxiang()
            screen.blit(preview[i], (bashen.x, 330))
            monster_control()
            reddragon.ishitted()
            boss.ishitted()
            zombie.ishitted()
            py.display.update()
            time.sleep(0.011)
        preview=[]
        bashen.key_up(K_u)
        reddragon.mark=0
        zombie.mark=0
        boss.mark=0
        action = -1
     #   lock=0
    elif len(preview)!=0 and action==2 and bashen.HP>=1:
        for i in range(27,len(preview)):
            screen.blit(img, (0, 0))  #blit的顺序是有讲究的需要先屏幕刷新
            display_touxiang()
            screen.blit(preview[i], (bashen.x, 227))
            monster_control()
            reddragon.ishitted()
            boss.ishitted()
            zombie.ishitted()
            py.display.update()
            time.sleep(0.011)
        preview = []
        zombie.mark=0
        bashen.key_up(K_i)
        reddragon.mark=0
        boss.mark=0
        action = -1
        lock=0
    elif bashen.HP<=0:
        bashen.hitted_act()
        py.mixer.init()
        for i in range(len(preview)):
            display_touxiang()
            screen.blit(img, (0, 0))
            screen.blit(preview[i],(bashen.x-20,bashen.y+30))
            py.display.update()
            time.sleep(0.018)
        screen.blit(youdied, (0, 0))
        py.display.update()
        time.sleep(2.5)
        game=0
if __name__=='__main__':
   main()
